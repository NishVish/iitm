(function () {

    const keyword = "mice";

    const pageText = document.body.innerText.toLowerCase();

    const found = pageText.includes(keyword.toLowerCase());

    const bar = document.createElement("div");

    bar.className = "keyword-checker-bar " + (found ? "found" : "not-found");

    bar.innerHTML = found
        ? `✅ Keyword Found: "${keyword}"`
        : `❌ Keyword Not Found: "${keyword}"`;

    const style = document.createElement("style");

    style.innerHTML = `
        .keyword-checker-bar {
            position: fixed;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            width: fit-content;
            padding: 12px 20px;
            z-index: 999999;
            text-align: center;
            font-size: 16px;
            font-family: Arial, sans-serif;
            font-weight: bold;
            color: white;
            box-sizing: border-box;
            pointer-events: none;
            border-radius: 8px;
        }

        .keyword-checker-bar.found {
            background: #16a34a;
        }

        .keyword-checker-bar.not-found {
            background: #dc2626;
        }
    `;

    document.head.appendChild(style);
    document.body.appendChild(bar);

    document.body.style.paddingBottom = "60px";

})();